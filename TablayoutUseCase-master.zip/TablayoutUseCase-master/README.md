# TablayoutUseCase
Tablayout所有使用场景，包括修改指示线长度、设置自定义图标、可滚动


先上效果图：分别为设置tab属性、去掉指示线、设置指示线长度、设置图标tab、超出屏幕滚动tab
![使用场景](http://upload-images.jianshu.io/upload_images/8669504-9506687adbd61b84.gif?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
